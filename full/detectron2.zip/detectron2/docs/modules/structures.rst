detectron2.structures 
=============================

.. automodule:: detectron2.structures
    :members:
    :undoc-members:
    :show-inheritance:
